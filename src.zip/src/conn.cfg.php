<?php

$connInfo = array(
    'conName:APPNAME:i:APIKEYGOESHERE:This is the connection for applicationName.infusionsoft.com');

?>