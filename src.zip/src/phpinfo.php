<?php

phpinfo();

?>